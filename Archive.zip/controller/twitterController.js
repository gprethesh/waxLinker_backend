const passport = require("passport");
const Twitter = require("twitter-api-client");
const { Api, JsonRpc, RpcError } = require("eosjs");
const { JsSignatureProvider } = require("eosjs/dist/eosjs-jssig"); // development only
let fetch;
import("node-fetch").then((module) => {
  fetch = module.default;
});
const { TextEncoder, TextDecoder } = require("util");

exports.authenticateTwitter = (req, res, next) => {
  // Continue with Twitter authentication

  // Store the actor in the session
  req.session.actor = req.query.actor;

  console.log(
    `Request method: ${req.method}, URL: ${req.url}, Session:`,
    req.session
  );

  console.log(`req.session`, req.session);

  // Continue with Twitter authentication
  passport.authenticate("twitter")(req, res, next);
};

exports.twitterCallback = (req, res) => {
  console.log("Session data:", req.session);
  console.log("Request query data:", req.query);

  const user_id = req.session.actor;
  console.log(`user_id`, user_id);
  // Create Twitter API client
  const twitterClient = new Twitter.TwitterClient({
    apiKey: process.env.TWITTER_API_KEY, // Your Twitter API Key
    apiSecret: process.env.TWITTER_API_SECRET_KEY,
    accessToken: req.user.twitter_token, // User's Access Token
    accessTokenSecret: req.user.twitter_tokenSecret, // User's Access Token Secret
  });

  // Retrieve user's Twitter username
  twitterClient.accountsAndUsers
    .accountSettings()
    .then(async (response) => {
      const twitterUsername = response.screen_name;

      // Setup EOSJS
      const privateKeys = [process.env.EOS_PRIVATE_KEY]; // Private key(s) to sign the transaction
      const signatureProvider = new JsSignatureProvider(privateKeys);
      const rpc = new JsonRpc("https://wax-testnet.eosphere.io", {
        fetch,
      });
      const api = new Api({
        rpc,
        signatureProvider,
        textDecoder: new TextDecoder(),
        textEncoder: new TextEncoder(),
      });

      // Prepare and send the transaction

      const twitterId = twitterUsername;

      const result = await api.transact(
        {
          actions: [
            {
              account: "pastacheetah", // Replace with your contract account name
              name: "addinfo",
              authorization: [
                {
                  actor: "pastacheetah",
                  permission: "active",
                },
              ],
              data: {
                user_id,
                twitterId,
              },
            },
          ],
        },
        {
          blocksBehind: 3,
          expireSeconds: 30,
        }
      );

      // Handle the response as needed
      res.send(
        `Welcome, ${twitterUsername}! Transaction ID: ${result.transaction_id}`
      );
    })
    .catch((error) => {
      console.log(`An error occurred: ${error}`);
      res.send(`An error occured ${error}`);
    });
};
